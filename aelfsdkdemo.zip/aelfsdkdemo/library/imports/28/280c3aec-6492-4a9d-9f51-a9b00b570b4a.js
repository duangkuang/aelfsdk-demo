"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    label: {
      "default": null,
      type: cc.Label
    },
    // defaults, set visually when attaching this script to the Canvas
    text: "Hello, World!"
  },
  // use this for initialization
  onLoad: function onLoad() {
    this.label.string = this.text; // 导入的时候会报 Can not find deps [long] for path : preview-scripts/assets/Script/aelf-sdk.js

    var AElf = require("aelf-sdk"); // 以下代码来自https://docs.aelf.io/en/latest/reference/chain-sdk/javascript/js-sdk.html#use-contract-instance
    // 下面这段可以调用


    var aelf = new AElf(new AElf.providers.HttpProvider("https://aelf-test-node.aelf.io"));
    aelf.chain.getChainStatus().then(function (chainStatus) {
      console.log(chainStatus);
    })["catch"](function (error) {
      console.error("Error fetching chain status:", error);
    }); // 这一段不可以调用报错 Uncaught TypeError: Unknown encoding: 2

    var newWallet = AElf.wallet.createNewWallet();
    console.log(newWallet);
  },
  // called every frame
  update: function update(dt) {}
});

cc._RF.pop();