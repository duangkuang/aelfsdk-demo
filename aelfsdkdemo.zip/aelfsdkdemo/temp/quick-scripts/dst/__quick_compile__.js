
(function () {
var scripts = [{"deps":{"./assets/Script/aelf-sdk":2,"./assets/Script/HelloWorld":1},"path":"preview-scripts/__qc_index__.js"},{"deps":{"aelf-sdk":2},"path":"preview-scripts/assets/Script/HelloWorld.js"},{"deps":{"fs":12,"../../../../../../../../ProgramData/cocos/editors/Creator/2.4.2/resources/app.asar/node_modules/process/browser.js":11,"path":9,"https":10,"child_process":12,"util":4,"buffer":8,"url":6,"assert":3,"http":7,"crypto":5},"path":"preview-scripts/assets/Script/aelf-sdk.js"},{"deps":{"util/":32},"path":"preview-scripts/__node_modules/assert/assert.js"},{"deps":{"../process/browser.js":11,"./support/isBuffer":13,"inherits":31},"path":"preview-scripts/__node_modules/util/util.js"},{"deps":{"randomfill":26,"randombytes":19,"create-hash":20,"pbkdf2":22,"browserify-sign/algos":55,"diffie-hellman":25,"create-hmac":21,"create-ecdh":23,"browserify-cipher":56,"public-encrypt":24,"browserify-sign":59},"path":"preview-scripts/__node_modules/crypto-browserify/index.js"},{"deps":{"punycode":15,"./util":16,"querystring":18},"path":"preview-scripts/__node_modules/url/url.js"},{"deps":{"url":6,"builtin-status-codes":27,"xtend":28,"./lib/response":17,"./lib/request":14},"path":"preview-scripts/__node_modules/stream-http/index.js"},{"deps":{"ieee754":29,"base64-js":30,"isarray":33},"path":"preview-scripts/__node_modules/buffer/index.js"},{"deps":{"../process/browser.js":11},"path":"preview-scripts/__node_modules/path-browserify/index.js"},{"deps":{"http":7},"path":"preview-scripts/__node_modules/https-browserify/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/process/browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify/lib/_empty.js"},{"deps":{},"path":"preview-scripts/__node_modules/util/support/isBufferBrowser.js"},{"deps":{"./response":17,"../../process/browser.js":11,"buffer":8,"./capability":34,"inherits":37,"to-arraybuffer":39,"readable-stream":38},"path":"preview-scripts/__node_modules/stream-http/lib/request.js"},{"deps":{},"path":"preview-scripts/__node_modules/punycode/punycode.js"},{"deps":{},"path":"preview-scripts/__node_modules/url/util.js"},{"deps":{"./capability":34,"../../process/browser.js":11,"buffer":8,"inherits":37,"readable-stream":38},"path":"preview-scripts/__node_modules/stream-http/lib/response.js"},{"deps":{"./decode":40,"./encode":41},"path":"preview-scripts/__node_modules/querystring-es3/index.js"},{"deps":{"../process/browser.js":11,"safe-buffer":49},"path":"preview-scripts/__node_modules/randombytes/browser.js"},{"deps":{"inherits":37,"ripemd160":50,"sha.js":51,"cipher-base":52,"md5.js":48},"path":"preview-scripts/__node_modules/create-hash/browser.js"},{"deps":{"inherits":37,"safe-buffer":49,"./legacy":42,"create-hash/md5":53,"sha.js":51,"cipher-base":52,"ripemd160":50},"path":"preview-scripts/__node_modules/create-hmac/browser.js"},{"deps":{"./lib/sync":43,"./lib/async":35},"path":"preview-scripts/__node_modules/pbkdf2/browser.js"},{"deps":{"buffer":8,"bn.js":60,"elliptic":57},"path":"preview-scripts/__node_modules/create-ecdh/browser.js"},{"deps":{"./privateDecrypt":44,"./publicEncrypt":46},"path":"preview-scripts/__node_modules/public-encrypt/browser.js"},{"deps":{"buffer":8,"./lib/primes.json":45,"./lib/dh":47,"./lib/generatePrime":36},"path":"preview-scripts/__node_modules/diffie-hellman/browser.js"},{"deps":{"../process/browser.js":11,"randombytes":19,"safe-buffer":49},"path":"preview-scripts/__node_modules/randomfill/browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/builtin-status-codes/browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/xtend/immutable.js"},{"deps":{},"path":"preview-scripts/__node_modules/ieee754/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/base64-js/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/util/node_modules/inherits/inherits_browser.js"},{"deps":{"../../../process/browser.js":11,"./support/isBuffer":54,"inherits":58},"path":"preview-scripts/__node_modules/assert/node_modules/util/util.js"},{"deps":{},"path":"preview-scripts/__node_modules/buffer/node_modules/isarray/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/stream-http/lib/capability.js"},{"deps":{"./sync":43,"../../process/browser.js":11,"safe-buffer":49,"./default-encoding":62,"./precondition":63},"path":"preview-scripts/__node_modules/pbkdf2/lib/async.js"},{"deps":{"randombytes":19,"bn.js":90,"miller-rabin":85},"path":"preview-scripts/__node_modules/diffie-hellman/lib/generatePrime.js"},{"deps":{},"path":"preview-scripts/__node_modules/inherits/inherits_browser.js"},{"deps":{"./lib/_stream_duplex.js":65,"./lib/_stream_transform.js":66,"./lib/_stream_passthrough.js":67,"./lib/_stream_writable.js":64,"./lib/_stream_readable.js":61},"path":"preview-scripts/__node_modules/readable-stream/readable-browser.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/to-arraybuffer/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/querystring-es3/decode.js"},{"deps":{},"path":"preview-scripts/__node_modules/querystring-es3/encode.js"},{"deps":{"inherits":37,"safe-buffer":49,"cipher-base":52},"path":"preview-scripts/__node_modules/create-hmac/legacy.js"},{"deps":{"./precondition":63,"./default-encoding":62,"create-hash/md5":53,"ripemd160":50,"sha.js":51,"safe-buffer":49},"path":"preview-scripts/__node_modules/pbkdf2/lib/sync-browser.js"},{"deps":{"create-hash":20,"safe-buffer":49,"parse-asn1":79,"bn.js":91,"./xor":69,"./mgf":68,"browserify-rsa":122,"./withPublic":70},"path":"preview-scripts/__node_modules/public-encrypt/privateDecrypt.js"},{"deps":{},"path":"preview-scripts/__node_modules/diffie-hellman/lib/primes.js"},{"deps":{"./mgf":68,"./xor":69,"./withPublic":70,"randombytes":19,"create-hash":20,"safe-buffer":49,"bn.js":91,"browserify-rsa":122,"parse-asn1":79},"path":"preview-scripts/__node_modules/public-encrypt/publicEncrypt.js"},{"deps":{"./generatePrime":36,"buffer":8,"bn.js":90,"miller-rabin":85,"randombytes":19},"path":"preview-scripts/__node_modules/diffie-hellman/lib/dh.js"},{"deps":{"inherits":37,"safe-buffer":49,"hash-base":80},"path":"preview-scripts/__node_modules/md5.js/index.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/safe-buffer/index.js"},{"deps":{"buffer":8,"inherits":37,"hash-base":80},"path":"preview-scripts/__node_modules/ripemd160/index.js"},{"deps":{"./sha1":72,"./sha224":73,"./sha256":74,"./sha384":75,"./sha512":78,"./sha":71},"path":"preview-scripts/__node_modules/sha.js/index.js"},{"deps":{"safe-buffer":49,"inherits":37,"string_decoder":77,"stream":76},"path":"preview-scripts/__node_modules/cipher-base/index.js"},{"deps":{"md5.js":48},"path":"preview-scripts/__node_modules/create-hash/md5.js"},{"deps":{},"path":"preview-scripts/__node_modules/assert/node_modules/util/support/isBufferBrowser.js"},{"deps":{"./browser/algorithms.json":98},"path":"preview-scripts/__node_modules/browserify-sign/algos.js"},{"deps":{"browserify-aes/browser":132,"evp_bytestokey":93,"browserify-des/modes":133,"browserify-des":135,"browserify-aes/modes":136},"path":"preview-scripts/__node_modules/browserify-cipher/browser.js"},{"deps":{"../package.json":86,"brorand":88,"./elliptic/curves":87,"./elliptic/curve":82,"./elliptic/utils":81,"./elliptic/ec":83,"./elliptic/eddsa":84},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic.js"},{"deps":{},"path":"preview-scripts/__node_modules/assert/node_modules/inherits/inherits_browser.js"},{"deps":{"./algorithms.json":98,"create-hash":20,"inherits":37,"./sign":123,"./verify":124,"safe-buffer":149,"readable-stream":142},"path":"preview-scripts/__node_modules/browserify-sign/browser/index.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/create-ecdh/node_modules/bn.js/lib/bn.js"},{"deps":{"./_stream_duplex":65,"../../process/browser.js":11,"safe-buffer":49,"inherits":37,"process-nextick-args":95,"core-util-is":105,"util":89,"events":92,"./internal/streams/stream":96,"isarray":104,"./internal/streams/destroy":103,"./internal/streams/BufferList":106,"string_decoder/":120},"path":"preview-scripts/__node_modules/readable-stream/lib/_stream_readable.js"},{"deps":{"../../process/browser.js":11},"path":"preview-scripts/__node_modules/pbkdf2/lib/default-encoding.js"},{"deps":{"../../is-buffer/index.js":94},"path":"preview-scripts/__node_modules/pbkdf2/lib/precondition.js"},{"deps":{"./internal/streams/stream":96,"./internal/streams/destroy":103,"./_stream_duplex":65,"../../process/browser.js":11,"inherits":37,"safe-buffer":49,"util-deprecate":97,"process-nextick-args":95,"core-util-is":105},"path":"preview-scripts/__node_modules/readable-stream/lib/_stream_writable.js"},{"deps":{"./_stream_readable":61,"./_stream_writable":64,"inherits":37,"process-nextick-args":95,"core-util-is":105},"path":"preview-scripts/__node_modules/readable-stream/lib/_stream_duplex.js"},{"deps":{"./_stream_duplex":65,"inherits":37,"core-util-is":105},"path":"preview-scripts/__node_modules/readable-stream/lib/_stream_transform.js"},{"deps":{"./_stream_transform":66,"inherits":37,"core-util-is":105},"path":"preview-scripts/__node_modules/readable-stream/lib/_stream_passthrough.js"},{"deps":{"create-hash":20,"safe-buffer":49},"path":"preview-scripts/__node_modules/public-encrypt/mgf.js"},{"deps":{},"path":"preview-scripts/__node_modules/public-encrypt/xor.js"},{"deps":{"bn.js":91,"safe-buffer":49},"path":"preview-scripts/__node_modules/public-encrypt/withPublic.js"},{"deps":{"inherits":37,"safe-buffer":49,"./hash":99},"path":"preview-scripts/__node_modules/sha.js/sha.js"},{"deps":{"./hash":99,"inherits":37,"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/sha1.js"},{"deps":{"./sha256":74,"./hash":99,"inherits":37,"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/sha224.js"},{"deps":{"./hash":99,"inherits":37,"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/sha256.js"},{"deps":{"./sha512":78,"./hash":99,"inherits":37,"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/sha384.js"},{"deps":{"events":92,"inherits":37,"readable-stream/readable.js":38,"readable-stream/writable.js":107,"readable-stream/duplex.js":108,"readable-stream/transform.js":109,"readable-stream/passthrough.js":110},"path":"preview-scripts/__node_modules/stream-browserify/index.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/string_decoder/index.js"},{"deps":{"./hash":99,"inherits":37,"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/sha512.js"},{"deps":{"pbkdf2":22,"safe-buffer":49,"./aesid.json":101,"./fixProc":102,"./asn1":100,"browserify-aes":132},"path":"preview-scripts/__node_modules/parse-asn1/index.js"},{"deps":{"inherits":37,"safe-buffer":125,"readable-stream":129},"path":"preview-scripts/__node_modules/hash-base/index.js"},{"deps":{"bn.js":130,"minimalistic-assert":121,"minimalistic-crypto-utils":127},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/utils.js"},{"deps":{"./base":111,"./short":112,"./edwards":113,"./mont":115},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curve/index.js"},{"deps":{"../utils":81,"../curves":87,"brorand":88,"./key":114,"./signature":116,"hmac-drbg":126,"bn.js":130},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/ec/index.js"},{"deps":{"../curves":87,"../utils":81,"./key":117,"./signature":118,"hash.js":128},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/eddsa/index.js"},{"deps":{"brorand":88,"bn.js":131},"path":"preview-scripts/__node_modules/miller-rabin/lib/mr.js"},{"deps":{},"path":"preview-scripts/__node_modules/elliptic/package.js"},{"deps":{"./curve":82,"./utils":81,"hash.js":128,"./precomputed/secp256k1":119},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curves.js"},{"deps":{"crypto":89},"path":"preview-scripts/__node_modules/brorand/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/browser-resolve/empty.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/diffie-hellman/node_modules/bn.js/lib/bn.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/public-encrypt/node_modules/bn.js/lib/bn.js"},{"deps":{},"path":"preview-scripts/__node_modules/events/events.js"},{"deps":{"safe-buffer":49,"md5.js":48},"path":"preview-scripts/__node_modules/evp_bytestokey/index.js"},{"deps":{},"path":"preview-scripts/__node_modules/is-buffer/index.js"},{"deps":{"../process/browser.js":11},"path":"preview-scripts/__node_modules/process-nextick-args/index.js"},{"deps":{"events":92},"path":"preview-scripts/__node_modules/readable-stream/lib/internal/streams/stream-browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/util-deprecate/browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-sign/browser/algorithms.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/sha.js/hash.js"},{"deps":{"./certificate":134,"asn1.js":137},"path":"preview-scripts/__node_modules/parse-asn1/asn1.js"},{"deps":{},"path":"preview-scripts/__node_modules/parse-asn1/aesid.js"},{"deps":{"evp_bytestokey":93,"safe-buffer":49,"browserify-aes":132},"path":"preview-scripts/__node_modules/parse-asn1/fixProc.js"},{"deps":{"process-nextick-args":95},"path":"preview-scripts/__node_modules/readable-stream/lib/internal/streams/destroy.js"},{"deps":{},"path":"preview-scripts/__node_modules/readable-stream/node_modules/isarray/index.js"},{"deps":{"../../is-buffer/index.js":94},"path":"preview-scripts/__node_modules/core-util-is/lib/util.js"},{"deps":{"util":89,"safe-buffer":49},"path":"preview-scripts/__node_modules/readable-stream/lib/internal/streams/BufferList.js"},{"deps":{"./lib/_stream_writable.js":64},"path":"preview-scripts/__node_modules/readable-stream/writable-browser.js"},{"deps":{"./lib/_stream_duplex.js":65},"path":"preview-scripts/__node_modules/readable-stream/duplex-browser.js"},{"deps":{"./readable":38},"path":"preview-scripts/__node_modules/readable-stream/transform.js"},{"deps":{"./readable":38},"path":"preview-scripts/__node_modules/readable-stream/passthrough.js"},{"deps":{"../utils":81,"bn.js":130},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curve/base.js"},{"deps":{"../utils":81,"./base":111,"bn.js":130,"inherits":37},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curve/short.js"},{"deps":{"../utils":81,"./base":111,"bn.js":130,"inherits":37},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curve/edwards.js"},{"deps":{"../utils":81,"bn.js":130},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/ec/key.js"},{"deps":{"./base":111,"../utils":81,"bn.js":130,"inherits":37},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/curve/mont.js"},{"deps":{"../utils":81,"bn.js":130},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/ec/signature.js"},{"deps":{"../utils":81},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/eddsa/key.js"},{"deps":{"../utils":81,"bn.js":130},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/eddsa/signature.js"},{"deps":{},"path":"preview-scripts/__node_modules/elliptic/lib/elliptic/precomputed/secp256k1.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/readable-stream/node_modules/string_decoder/lib/string_decoder.js"},{"deps":{},"path":"preview-scripts/__node_modules/minimalistic-assert/index.js"},{"deps":{"buffer":8,"randombytes":19,"bn.js":211},"path":"preview-scripts/__node_modules/browserify-rsa/index.js"},{"deps":{"create-hmac":21,"elliptic":57,"parse-asn1":79,"bn.js":153,"safe-buffer":149,"browserify-rsa":122,"./curves.json":152},"path":"preview-scripts/__node_modules/browserify-sign/browser/sign.js"},{"deps":{"./curves.json":152,"elliptic":57,"parse-asn1":79,"safe-buffer":149,"bn.js":153},"path":"preview-scripts/__node_modules/browserify-sign/browser/verify.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/hash-base/node_modules/safe-buffer/index.js"},{"deps":{"hash.js":128,"minimalistic-crypto-utils":127,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/hmac-drbg/lib/hmac-drbg.js"},{"deps":{},"path":"preview-scripts/__node_modules/minimalistic-crypto-utils/lib/utils.js"},{"deps":{"./hash/utils":138,"./hash/ripemd":143,"./hash/common":140,"./hash/hmac":144,"./hash/sha":141},"path":"preview-scripts/__node_modules/hash.js/lib/hash.js"},{"deps":{"./lib/_stream_writable.js":145,"./lib/_stream_duplex.js":146,"./lib/_stream_transform.js":147,"./lib/internal/streams/end-of-stream.js":150,"./lib/_stream_passthrough.js":148,"./lib/internal/streams/pipeline.js":151,"./lib/_stream_readable.js":139},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/readable-browser.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/elliptic/node_modules/bn.js/lib/bn.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/miller-rabin/node_modules/bn.js/lib/bn.js"},{"deps":{"./modes/list.json":172,"./decrypter":173,"./encrypter":171},"path":"preview-scripts/__node_modules/browserify-aes/browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-des/modes.js"},{"deps":{"asn1.js":137},"path":"preview-scripts/__node_modules/parse-asn1/certificate.js"},{"deps":{"cipher-base":52,"inherits":37,"safe-buffer":49,"des.js":174},"path":"preview-scripts/__node_modules/browserify-des/index.js"},{"deps":{"./list.json":172,"./ecb":179,"./cfb8":180,"./cfb1":184,"./ofb":183,"./cfb":178,"./cbc":177,"./ctr":182},"path":"preview-scripts/__node_modules/browserify-aes/modes/index.js"},{"deps":{"bn.js":176,"./asn1/constants":156,"./asn1/base":154,"./asn1/decoders":157,"./asn1/encoders":158,"./asn1/api":155},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1.js"},{"deps":{"minimalistic-assert":121,"inherits":37},"path":"preview-scripts/__node_modules/hash.js/lib/hash/utils.js"},{"deps":{"events":92,"buffer":8,"util":89,"./_stream_duplex":146,"../../../../process/browser.js":11,"inherits":37,"../errors":161,"./internal/streams/from":165,"./internal/streams/stream":160,"./internal/streams/destroy":162,"./internal/streams/buffer_list":163,"./internal/streams/async_iterator":164,"./internal/streams/state":166,"string_decoder/":175},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/_stream_readable.js"},{"deps":{"./utils":138,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/hash.js/lib/hash/common.js"},{"deps":{"./sha/224":167,"./sha/384":170,"./sha/256":168,"./sha/512":169,"./sha/1":159},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha.js"},{"deps":{"./lib/_stream_duplex.js":192,"./lib/_stream_passthrough.js":195,"./lib/internal/streams/pipeline.js":197,"./lib/internal/streams/end-of-stream.js":200,"./lib/_stream_transform.js":196,"./lib/_stream_writable.js":198,"./lib/_stream_readable.js":205},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/readable-browser.js"},{"deps":{"./utils":138,"./common":140},"path":"preview-scripts/__node_modules/hash.js/lib/hash/ripemd.js"},{"deps":{"./utils":138,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/hash.js/lib/hash/hmac.js"},{"deps":{"./internal/streams/stream":160,"buffer":8,"./internal/streams/destroy":162,"../errors":161,"./internal/streams/state":166,"./_stream_duplex":146,"../../../../process/browser.js":11,"util-deprecate":97,"inherits":37},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/_stream_writable.js"},{"deps":{"./_stream_readable":139,"./_stream_writable":145,"../../../../process/browser.js":11,"inherits":37},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/_stream_duplex.js"},{"deps":{"../errors":161,"./_stream_duplex":146,"inherits":37},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/_stream_transform.js"},{"deps":{"./_stream_transform":147,"inherits":37},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/_stream_passthrough.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/safe-buffer/index.js"},{"deps":{"../../../errors":161},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/end-of-stream.js"},{"deps":{"../../../errors":161,"./end-of-stream":150},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/pipeline.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-sign/browser/curves.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/bn.js/lib/bn.js"},{"deps":{"./reporter":181,"./node":186,"./buffer":187},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/base/index.js"},{"deps":{"../asn1":137,"inherits":37,"vm":190},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/api.js"},{"deps":{"./der":185},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/constants/index.js"},{"deps":{"./pem":188,"./der":189},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/decoders/index.js"},{"deps":{"./der":191,"./pem":193},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/encoders/index.js"},{"deps":{"../utils":138,"../common":140,"./common":194},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/1.js"},{"deps":{"events":92},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/stream-browser.js"},{"deps":{},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/errors-browser.js"},{"deps":{"../../../../../../process/browser.js":11},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/destroy.js"},{"deps":{"buffer":8,"util":89},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/buffer_list.js"},{"deps":{"./end-of-stream":150,"../../../../../../process/browser.js":11},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/async_iterator.js"},{"deps":{},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/from-browser.js"},{"deps":{"../../../errors":161},"path":"preview-scripts/__node_modules/hash-base/node_modules/readable-stream/lib/internal/streams/state.js"},{"deps":{"../utils":138,"./256":168},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/224.js"},{"deps":{"../utils":138,"../common":140,"./common":194,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/256.js"},{"deps":{"../utils":138,"../common":140,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/512.js"},{"deps":{"../utils":138,"./512":169},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/384.js"},{"deps":{"./modes":136,"safe-buffer":49,"cipher-base":52,"inherits":37,"evp_bytestokey":93,"./streamCipher":207,"./aes":209,"./authCipher":208},"path":"preview-scripts/__node_modules/browserify-aes/encrypter.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-aes/modes/list.js"},{"deps":{"./authCipher":208,"./modes":136,"./streamCipher":207,"./aes":209,"safe-buffer":49,"cipher-base":52,"inherits":37,"evp_bytestokey":93},"path":"preview-scripts/__node_modules/browserify-aes/decrypter.js"},{"deps":{"./des/utils":199,"./des/cipher":201,"./des/des":202,"./des/cbc":203,"./des/ede":204},"path":"preview-scripts/__node_modules/des.js/lib/des.js"},{"deps":{"safe-buffer":125},"path":"preview-scripts/__node_modules/hash-base/node_modules/string_decoder/lib/string_decoder.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/asn1.js/node_modules/bn.js/lib/bn.js"},{"deps":{"buffer-xor":210},"path":"preview-scripts/__node_modules/browserify-aes/modes/cbc.js"},{"deps":{"safe-buffer":49,"buffer-xor":210},"path":"preview-scripts/__node_modules/browserify-aes/modes/cfb.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-aes/modes/ecb.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/browserify-aes/modes/cfb8.js"},{"deps":{"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/base/reporter.js"},{"deps":{"safe-buffer":49,"buffer-xor":210,"../incr32":212},"path":"preview-scripts/__node_modules/browserify-aes/modes/ctr.js"},{"deps":{"buffer":8,"buffer-xor":210},"path":"preview-scripts/__node_modules/browserify-aes/modes/ofb.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/browserify-aes/modes/cfb1.js"},{"deps":{"../constants":156},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/constants/der.js"},{"deps":{"../base":154,"minimalistic-assert":121},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/base/node.js"},{"deps":{"../base":154,"buffer":8,"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/base/buffer.js"},{"deps":{"buffer":8,"./der":189,"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/decoders/pem.js"},{"deps":{"../../asn1":137,"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/decoders/der.js"},{"deps":{"indexof":206},"path":"preview-scripts/__node_modules/vm-browserify/index.js"},{"deps":{"buffer":8,"../../asn1":137,"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/encoders/der.js"},{"deps":{"./_stream_readable":205,"./_stream_writable":198,"../../../../process/browser.js":11,"inherits":37},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/_stream_duplex.js"},{"deps":{"./der":191,"inherits":37},"path":"preview-scripts/__node_modules/asn1.js/lib/asn1/encoders/pem.js"},{"deps":{"../utils":138},"path":"preview-scripts/__node_modules/hash.js/lib/hash/sha/common.js"},{"deps":{"./_stream_transform":196,"inherits":37},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/_stream_passthrough.js"},{"deps":{"./_stream_duplex":192,"inherits":37,"../errors":213},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/_stream_transform.js"},{"deps":{"../../../errors":213,"./end-of-stream":200},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/pipeline.js"},{"deps":{"buffer":8,"../errors":213,"./_stream_duplex":192,"../../../../process/browser.js":11,"util-deprecate":97,"inherits":37,"./internal/streams/stream":214,"./internal/streams/destroy":215,"./internal/streams/state":216},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/_stream_writable.js"},{"deps":{},"path":"preview-scripts/__node_modules/des.js/lib/des/utils.js"},{"deps":{"../../../errors":213},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/end-of-stream.js"},{"deps":{"minimalistic-assert":121},"path":"preview-scripts/__node_modules/des.js/lib/des/cipher.js"},{"deps":{"./utils":199,"./cipher":201,"minimalistic-assert":121,"inherits":37},"path":"preview-scripts/__node_modules/des.js/lib/des/des.js"},{"deps":{"minimalistic-assert":121,"inherits":37},"path":"preview-scripts/__node_modules/des.js/lib/des/cbc.js"},{"deps":{"./cipher":201,"./des":202,"minimalistic-assert":121,"inherits":37},"path":"preview-scripts/__node_modules/des.js/lib/des/ede.js"},{"deps":{"events":92,"./internal/streams/stream":214,"util":89,"buffer":8,"./internal/streams/destroy":215,"./internal/streams/state":216,"../errors":213,"./_stream_duplex":192,"../../../../process/browser.js":11,"inherits":37,"./internal/streams/from":219,"./internal/streams/buffer_list":217,"./internal/streams/async_iterator":218,"string_decoder/":221},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/_stream_readable.js"},{"deps":{},"path":"preview-scripts/__node_modules/indexof/index.js"},{"deps":{"./aes":209,"cipher-base":52,"safe-buffer":49,"inherits":37},"path":"preview-scripts/__node_modules/browserify-aes/streamCipher.js"},{"deps":{"./aes":209,"./incr32":212,"inherits":37,"cipher-base":52,"buffer-xor":210,"safe-buffer":49,"./ghash":220},"path":"preview-scripts/__node_modules/browserify-aes/authCipher.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/browserify-aes/aes.js"},{"deps":{"buffer":8},"path":"preview-scripts/__node_modules/buffer-xor/index.js"},{"deps":{"buffer":89},"path":"preview-scripts/__node_modules/browserify-rsa/node_modules/bn.js/lib/bn.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-aes/incr32.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/errors-browser.js"},{"deps":{"events":92},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/stream-browser.js"},{"deps":{"../../../../../../process/browser.js":11},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/destroy.js"},{"deps":{"../../../errors":213},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/state.js"},{"deps":{"buffer":8,"util":89},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/buffer_list.js"},{"deps":{"./end-of-stream":200,"../../../../../../process/browser.js":11},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/async_iterator.js"},{"deps":{},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/readable-stream/lib/internal/streams/from-browser.js"},{"deps":{"safe-buffer":49},"path":"preview-scripts/__node_modules/browserify-aes/ghash.js"},{"deps":{"safe-buffer":149},"path":"preview-scripts/__node_modules/browserify-sign/node_modules/string_decoder/lib/string_decoder.js"}];
var entries = ["preview-scripts/__qc_index__.js"];
var bundleScript = 'preview-scripts/__qc_bundle__.js';

/**
 * Notice: This file can not use ES6 (for IE 11)
 */
var modules = {};
var name2path = {};

// Will generated by module.js plugin
// var scripts = ${scripts};
// var entries = ${entries};
// var bundleScript = ${bundleScript};

if (typeof global === 'undefined') {
    window.global = window;
}

var isJSB = typeof jsb !== 'undefined';

function getXMLHttpRequest () {
    return window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject('MSXML2.XMLHTTP');
}

function downloadText(url, callback) {
    if (isJSB) {
        var result = jsb.fileUtils.getStringFromFile(url);
        callback(null, result);
        return;
    }

    var xhr = getXMLHttpRequest(),
        errInfo = 'Load text file failed: ' + url;
    xhr.open('GET', url, true);
    if (xhr.overrideMimeType) xhr.overrideMimeType('text\/plain; charset=utf-8');
    xhr.onload = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 0) {
                callback(null, xhr.responseText);
            }
            else {
                callback({status:xhr.status, errorMessage:errInfo + ', status: ' + xhr.status});
            }
        }
        else {
            callback({status:xhr.status, errorMessage:errInfo + '(wrong readyState)'});
        }
    };
    xhr.onerror = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(error)'});
    };
    xhr.ontimeout = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
    };
    xhr.send(null);
};

function loadScript (src, cb) {
    if (typeof require !== 'undefined') {
        require(src);
        return cb();
    }

    // var timer = 'load ' + src;
    // console.time(timer);

    var scriptElement = document.createElement('script');

    function done() {
        // console.timeEnd(timer);
        // deallocation immediate whatever
        scriptElement.remove();
    }

    scriptElement.onload = function () {
        done();
        cb();
    };
    scriptElement.onerror = function () {
        done();
        var error = 'Failed to load ' + src;
        console.error(error);
        cb(new Error(error));
    };
    scriptElement.setAttribute('type','text/javascript');
    scriptElement.setAttribute('charset', 'utf-8');
    scriptElement.setAttribute('src', src);

    document.head.appendChild(scriptElement);
}

function loadScripts (srcs, cb) {
    var n = srcs.length;

    srcs.forEach(function (src) {
        loadScript(src, function () {
            n--;
            if (n === 0) {
                cb();
            }
        });
    })
}

function formatPath (path) {
    let destPath = window.__quick_compile_project__.destPath;
    if (destPath) {
        let prefix = 'preview-scripts';
        if (destPath[destPath.length - 1] === '/') {
            prefix += '/';
        }
        path = path.replace(prefix, destPath);
    }
    return path;
}

window.__quick_compile_project__ = {
    destPath: '',

    registerModule: function (path, module) {
        path = formatPath(path);
        modules[path].module = module;
    },

    registerModuleFunc: function (path, func) {
        path = formatPath(path);
        modules[path].func = func;

        var sections = path.split('/');
        var name = sections[sections.length - 1];
        name = name.replace(/\.(?:js|ts|json)$/i, '');
        name2path[name] = path;
    },

    require: function (request, path) {
        var m, requestScript;

        path = formatPath(path);
        if (path) {
            m = modules[path];
            if (!m) {
                console.warn('Can not find module for path : ' + path);
                return null;
            }
        }

        if (m) {
            let depIndex = m.deps[request];
            // dependence script was excluded
            if (depIndex === -1) {
                return null;
            }
            else {
                requestScript = scripts[ m.deps[request] ];
            }
        }
        
        let requestPath = '';
        if (!requestScript) {
            // search from name2path when request is a dynamic module name
            if (/^[\w- .]*$/.test(request)) {
                requestPath = name2path[request];
            }

            if (!requestPath) {
                if (CC_JSB) {
                    return require(request);
                }
                else {
                    console.warn('Can not find deps [' + request + '] for path : ' + path);
                    return null;
                }
            }
        }
        else {
            requestPath = formatPath(requestScript.path);
        }

        let requestModule = modules[requestPath];
        if (!requestModule) {
            console.warn('Can not find request module for path : ' + requestPath);
            return null;
        }

        if (!requestModule.module && requestModule.func) {
            requestModule.func();
        }

        if (!requestModule.module) {
            console.warn('Can not find requestModule.module for path : ' + path);
            return null;
        }

        return requestModule.module.exports;
    },

    run: function () {
        entries.forEach(function (entry) {
            entry = formatPath(entry);
            var module = modules[entry];
            if (!module.module) {
                module.func();
            }
        });
    },

    load: function (cb) {
        var self = this;

        var srcs = scripts.map(function (script) {
            var path = formatPath(script.path);
            modules[path] = script;

            if (script.mtime) {
                path += ("?mtime=" + script.mtime);
            }
            return path;
        });

        console.time && console.time('load __quick_compile_project__');
        // jsb can not analysis sourcemap, so keep separate files.
        if (bundleScript && !isJSB) {
            downloadText(formatPath(bundleScript), function (err, bundleSource) {
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                if (err) {
                    console.error(err);
                    return;
                }

                let evalTime = 'eval __quick_compile_project__ : ' + srcs.length + ' files';
                console.time && console.time(evalTime);
                var sources = bundleSource.split('\n//------QC-SOURCE-SPLIT------\n');
                for (var i = 0; i < sources.length; i++) {
                    if (sources[i]) {
                        window.eval(sources[i]);
                        // not sure why new Function cannot set breakpoints precisely
                        // new Function(sources[i])()
                    }
                }
                self.run();
                console.timeEnd && console.timeEnd(evalTime);
                cb();
            })
        }
        else {
            loadScripts(srcs, function () {
                self.run();
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                cb();
            });
        }
    }
};

// Polyfill for IE 11
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function () {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
})();
    