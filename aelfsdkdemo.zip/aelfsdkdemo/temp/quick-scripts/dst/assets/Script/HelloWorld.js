
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/HelloWorld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    label: {
      "default": null,
      type: cc.Label
    },
    // defaults, set visually when attaching this script to the Canvas
    text: "Hello, World!"
  },
  // use this for initialization
  onLoad: function onLoad() {
    this.label.string = this.text; // 导入的时候会报 Can not find deps [long] for path : preview-scripts/assets/Script/aelf-sdk.js

    var AElf = require("aelf-sdk"); // 以下代码来自https://docs.aelf.io/en/latest/reference/chain-sdk/javascript/js-sdk.html#use-contract-instance
    // 下面这段可以调用


    var aelf = new AElf(new AElf.providers.HttpProvider("https://aelf-test-node.aelf.io"));
    aelf.chain.getChainStatus().then(function (chainStatus) {
      console.log(chainStatus);
    })["catch"](function (error) {
      console.error("Error fetching chain status:", error);
    }); // 这一段不可以调用报错 Uncaught TypeError: Unknown encoding: 2

    var newWallet = AElf.wallet.createNewWallet();
    console.log(newWallet);
  },
  // called every frame
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxIZWxsb1dvcmxkLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibGFiZWwiLCJ0eXBlIiwiTGFiZWwiLCJ0ZXh0Iiwib25Mb2FkIiwic3RyaW5nIiwiQUVsZiIsInJlcXVpcmUiLCJhZWxmIiwicHJvdmlkZXJzIiwiSHR0cFByb3ZpZGVyIiwiY2hhaW4iLCJnZXRDaGFpblN0YXR1cyIsInRoZW4iLCJjaGFpblN0YXR1cyIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsIm5ld1dhbGxldCIsIndhbGxldCIsImNyZWF0ZU5ld1dhbGxldCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNQLGFBQVNELEVBQUUsQ0FBQ0UsU0FETDtBQUdQQyxFQUFBQSxVQUFVLEVBQUU7QUFDVkMsSUFBQUEsS0FBSyxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSixLQURHO0FBS1Y7QUFDQUMsSUFBQUEsSUFBSSxFQUFFO0FBTkksR0FITDtBQVlQO0FBQ0FDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNsQixTQUFLSixLQUFMLENBQVdLLE1BQVgsR0FBb0IsS0FBS0YsSUFBekIsQ0FEa0IsQ0FHbEI7O0FBQ0EsUUFBSUcsSUFBSSxHQUFHQyxPQUFPLENBQUMsVUFBRCxDQUFsQixDQUprQixDQU1sQjtBQUNBOzs7QUFDQSxRQUFNQyxJQUFJLEdBQUcsSUFBSUYsSUFBSixDQUNYLElBQUlBLElBQUksQ0FBQ0csU0FBTCxDQUFlQyxZQUFuQixDQUFnQyxnQ0FBaEMsQ0FEVyxDQUFiO0FBR0FGLElBQUFBLElBQUksQ0FBQ0csS0FBTCxDQUNHQyxjQURILEdBRUdDLElBRkgsQ0FFUSxVQUFDQyxXQUFELEVBQWlCO0FBQ3JCQyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsV0FBWjtBQUNELEtBSkgsV0FLUyxVQUFDRyxLQUFELEVBQVc7QUFDaEJGLE1BQUFBLE9BQU8sQ0FBQ0UsS0FBUixDQUFjLDhCQUFkLEVBQThDQSxLQUE5QztBQUNELEtBUEgsRUFYa0IsQ0FtQmxCOztBQUNBLFFBQU1DLFNBQVMsR0FBR1osSUFBSSxDQUFDYSxNQUFMLENBQVlDLGVBQVosRUFBbEI7QUFDQUwsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlFLFNBQVo7QUFDRCxHQW5DTTtBQXFDUDtBQUNBRyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVVDLEVBQVYsRUFBYyxDQUFFO0FBdENqQixDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICBwcm9wZXJ0aWVzOiB7XHJcbiAgICBsYWJlbDoge1xyXG4gICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICB0eXBlOiBjYy5MYWJlbCxcclxuICAgIH0sXHJcbiAgICAvLyBkZWZhdWx0cywgc2V0IHZpc3VhbGx5IHdoZW4gYXR0YWNoaW5nIHRoaXMgc2NyaXB0IHRvIHRoZSBDYW52YXNcclxuICAgIHRleHQ6IFwiSGVsbG8sIFdvcmxkIVwiLFxyXG4gIH0sXHJcblxyXG4gIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgdGhpcy5sYWJlbC5zdHJpbmcgPSB0aGlzLnRleHQ7XHJcblxyXG4gICAgLy8g5a+85YWl55qE5pe25YCZ5Lya5oqlIENhbiBub3QgZmluZCBkZXBzIFtsb25nXSBmb3IgcGF0aCA6IHByZXZpZXctc2NyaXB0cy9hc3NldHMvU2NyaXB0L2FlbGYtc2RrLmpzXHJcbiAgICB2YXIgQUVsZiA9IHJlcXVpcmUoXCJhZWxmLXNka1wiKTtcclxuXHJcbiAgICAvLyDku6XkuIvku6PnoIHmnaXoh6podHRwczovL2RvY3MuYWVsZi5pby9lbi9sYXRlc3QvcmVmZXJlbmNlL2NoYWluLXNkay9qYXZhc2NyaXB0L2pzLXNkay5odG1sI3VzZS1jb250cmFjdC1pbnN0YW5jZVxyXG4gICAgLy8g5LiL6Z2i6L+Z5q615Y+v5Lul6LCD55SoXHJcbiAgICBjb25zdCBhZWxmID0gbmV3IEFFbGYoXHJcbiAgICAgIG5ldyBBRWxmLnByb3ZpZGVycy5IdHRwUHJvdmlkZXIoXCJodHRwczovL2FlbGYtdGVzdC1ub2RlLmFlbGYuaW9cIilcclxuICAgICk7XHJcbiAgICBhZWxmLmNoYWluXHJcbiAgICAgIC5nZXRDaGFpblN0YXR1cygpXHJcbiAgICAgIC50aGVuKChjaGFpblN0YXR1cykgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGNoYWluU3RhdHVzKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjaGFpbiBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgICAvLyDov5nkuIDmrrXkuI3lj6/ku6XosIPnlKjmiqXplJkgVW5jYXVnaHQgVHlwZUVycm9yOiBVbmtub3duIGVuY29kaW5nOiAyXHJcbiAgICBjb25zdCBuZXdXYWxsZXQgPSBBRWxmLndhbGxldC5jcmVhdGVOZXdXYWxsZXQoKTtcclxuICAgIGNvbnNvbGUubG9nKG5ld1dhbGxldCk7XHJcbiAgfSxcclxuXHJcbiAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lXHJcbiAgdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHt9LFxyXG59KTtcclxuIl19