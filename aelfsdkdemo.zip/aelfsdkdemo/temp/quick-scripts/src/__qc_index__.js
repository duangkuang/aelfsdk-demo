
require('./assets/Script/HelloWorld');
require('./assets/Script/aelf-sdk');
