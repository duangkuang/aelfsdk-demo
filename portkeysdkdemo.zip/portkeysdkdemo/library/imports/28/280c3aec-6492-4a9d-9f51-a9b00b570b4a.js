"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

"use strict";

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

cc.Class({
  "extends": cc.Component,
  properties: {
    label: {
      "default": null,
      type: cc.Label
    },
    // defaults, set visually when attaching this script to the Canvas
    text: "Hello, World!"
  },
  // use this for initialization
  onLoad: function onLoad() {
    this.label.string = this.text; // 导入的时候会报 Can not find deps [long] for path : preview-scripts/assets/Script/aelf-sdk.js
    // var AElf = require("aelf-sdk");
    // // 以下代码来自https://docs.aelf.io/en/latest/reference/chain-sdk/javascript/js-sdk.html#use-contract-instance
    // // 下面这段可以调用
    // const aelf = new AElf(
    //   new AElf.providers.HttpProvider("https://aelf-test-node.aelf.io")
    // );
    // aelf.chain
    //   .getChainStatus()
    //   .then((chainStatus) => {
    //     console.log(chainStatus);
    //   })
    //   .catch((error) => {
    //     console.error("Error fetching chain status:", error);
    //   });
    // // 这一段不可以调用报错 Uncaught TypeError: Unknown encoding: 2
    // const newWallet = AElf.wallet.createNewWallet();
    // console.log(newWallet);

    var _require = require("@portkey/did"),
        DID = _require.DID;

    var did = new DID();
    did.setConfig({
      requestDefaults: {
        baseURL: "https://did-portkey-test.portkey.finance",
        timeout: "10000" // optional default 8000ms

      },
      graphQLUrl: "https://dapp-portkey-test.portkey.finance/Portkey_DID/PortKeyIndexerCASchema/graphql",
      storageMethod: "local"
    });

    _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      var a;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return did.services.getChainsInfo();

            case 2:
              a = _context.sent;

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  // called every frame
  update: function update(dt) {}
});

cc._RF.pop();