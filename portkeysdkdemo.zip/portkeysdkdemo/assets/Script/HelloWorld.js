cc.Class({
  extends: cc.Component,

  properties: {
    label: {
      default: null,
      type: cc.Label,
    },
    // defaults, set visually when attaching this script to the Canvas
    text: "Hello, World!",
  },

  // use this for initialization
  onLoad: function () {
    this.label.string = this.text;

    // 导入的时候会报 Can not find deps [long] for path : preview-scripts/assets/Script/aelf-sdk.js
    // var AElf = require("aelf-sdk");

    // // 以下代码来自https://docs.aelf.io/en/latest/reference/chain-sdk/javascript/js-sdk.html#use-contract-instance
    // // 下面这段可以调用
    // const aelf = new AElf(
    //   new AElf.providers.HttpProvider("https://aelf-test-node.aelf.io")
    // );
    // aelf.chain
    //   .getChainStatus()
    //   .then((chainStatus) => {
    //     console.log(chainStatus);
    //   })
    //   .catch((error) => {
    //     console.error("Error fetching chain status:", error);
    //   });
    // // 这一段不可以调用报错 Uncaught TypeError: Unknown encoding: 2
    // const newWallet = AElf.wallet.createNewWallet();
    // console.log(newWallet);
    const { DID } = require("@portkey/did");

    const did = new DID();
    did.setConfig({
      requestDefaults: {
        baseURL: "https://did-portkey-test.portkey.finance",
        timeout: "10000", // optional default 8000ms
      },
      graphQLUrl:
        "https://dapp-portkey-test.portkey.finance/Portkey_DID/PortKeyIndexerCASchema/graphql",
      storageMethod: "local",
    });

    (async () => {
      const a = await did.services.getChainsInfo();
      //console.log(await did.getVerifierServers(a[0].chainId));
    })();
  },

  // called every frame
  update: function (dt) {},
});
